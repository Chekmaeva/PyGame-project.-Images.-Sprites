import pygame
import os

pygame.init()
size = width, height = 600, 95
screen = pygame.display.set_mode(size)
clock = pygame.time.Clock()


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname)
    except pygame.error as message:
        print('Cannot load image:', name)
        raise SystemExit(message)
    image = image.convert_alpha()

    if colorkey is not None:
        if colorkey is -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    image1 = pygame.transform.scale(image, (102, 95))
    return image


car = load_image('car2.png')
car2 = pygame.transform.flip(car, True, False)
x = 0
y = 0
xx = 450

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    if x < 450:
        x += 1
        screen.fill((255, 255, 255))
        screen.blit(car, (x, y))
        pygame.display.flip()
        clock.tick(500)
    if x == 450:
        if xx != 0:
            xx -= 1
            screen.fill((255, 255, 255))
            screen.blit(car2, (xx, y))
            pygame.display.flip()
            clock.tick(500)
pygame.quit()
