import os
import random
import pygame


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname)
    except pygame.error as message:
        print('Cannot load image:', name)
        raise SystemExit(message)
    image = image.convert_alpha()

    if colorkey is not None:
        if colorkey is -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    return image

size = width, height = 600, 300
screen = pygame.display.set_mode(size)
clock = pygame.time.Clock()
background = load_image('gameover.png')

step = -700
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    screen.fill(pygame.Color('Blue'))
    if step < 0:
        step += 1
    screen.blit(background, (step, 0))
    pygame.display.flip()
    clock.tick(200)
pygame.quit()
