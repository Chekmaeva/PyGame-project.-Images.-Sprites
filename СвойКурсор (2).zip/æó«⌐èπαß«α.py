import pygame
import os

size = width, height = 500, 500
screen = pygame.display.set_mode(size)
clock = pygame.time.Clock()
pygame.mouse.set_visible(False)


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname)
    except pygame.error as message:
        print('Cannot load image:', name)
        raise SystemExit(message)
    image = image.convert_alpha()

    if colorkey is not None:
        if colorkey is -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    return image

MANUAL_CURSOR = load_image('arrow.png')

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEMOTION:
            t = pygame.mouse.get_focused()
            if t is True:
                screen.blit(MANUAL_CURSOR, (pygame.mouse.get_pos()))
                pygame.display.update()
                screen.fill((0, 0, 0))
pygame.quit()
